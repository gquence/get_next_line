/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dmelessa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/06 04:14:34 by dmelessa          #+#    #+#             */
/*   Updated: 2019/02/06 04:18:17 by dmelessa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s)
{
	char		*p;
	const char	*sp;
	const char	*ep;

	if (!s)
		return (NULL);
	while (ft_isspace(*s))
		s++;
	sp = s;
	ep = sp;
	while (*sp)
	{
		while (*sp && ft_isalpha(*sp))
			sp++;
		ep = sp;
		while (*sp && ft_isspace(*sp))
			sp++;
	}
	sp = s;
	if (!(p = (char *)malloc(ep - s + 1)))
		return (NULL);
	while (s < ep)
		*p++ = *((char *)s++);
	*p = '\0';
	return (p - (ep - sp));
}
